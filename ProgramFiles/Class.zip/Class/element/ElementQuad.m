classdef ElementQuad < Element
    %ELEMENTQUAD Summary of this class goes here
    %   Detailed explanation goes here
    
    methods
        function [Xi,WF] = QuadratureVolume(obj)
            pt = 1/sqrt(3);
            Xi=[-pt,-pt, pt, pt
                -pt, pt,-pt, pt];
            WF=[1,1,1,1];
        end
        
        function [HatP,DHatP1,DHatP2] = LocalBasisVolume(obj,Xi)
            xi_1 = Xi(1,:);
            xi_2 = Xi(2,:);
            
            HatP=[(1-xi_1).*(1-xi_2)/4; (1+xi_1).*(1-xi_2)/4;
                (1+xi_1).*(1+xi_2)/4; (1-xi_1).*(1+xi_2)/4 ];
            DHatP1 = [-(1-xi_2)/4;  (1-xi_2)/4;
                (1+xi_2)/4; -(1+xi_2)/4 ];
            DHatP2 = [-(1-xi_1)/4; -(1+xi_1)/4;
                (1+xi_1)/4;  (1-xi_1)/4 ];
            
        end
    end
end

