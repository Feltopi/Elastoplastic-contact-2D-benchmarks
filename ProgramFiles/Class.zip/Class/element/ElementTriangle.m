classdef ElementTriangle < Element
    %ELEMENTQUAD Summary of this class goes here
    %   Detailed explanation goes here
    
    methods
        function [Xi,WF] = QuadratureVolume(obj)
            Xi=[1/3; 1/3]; 
            WF=1/2;
        end
        
        function [HatP,DHatP1,DHatP2] = LocalBasisVolume(obj,Xi)
            xi_1 = Xi(1,:);
            xi_2 = Xi(2,:);
            
            HatP = [1-xi_1-xi_2; xi_1; xi_2] ;
            DHatP1 = [ -1; 1; 0];
            DHatP2 = [ -1; 0; 1];
        end
    end
end

