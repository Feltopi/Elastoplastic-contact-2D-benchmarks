classdef ElementType
    enumeration
        % 1D elements
        LineSegment

        % 2D elements
        Triangle
        Quad          % a square connecting four nodes [idx1, idx2, idx3, idx4]
        
        % 3D elements
        Tetrahedron
        Hexahedron
    end
    
    methods
        function nmb = int(obj)
            nmb = [];
            switch obj
                case ElementType.LineSegment
                    nmb = 1;
                case ElementType.Triangle
                    nmb = 2;
                case ElementType.Quad
                    nmb = 3;
                case ElementType.Tetrahedron
                    nmb = 4;
                case ElementType.Hexahedron
                    nmb = 5;
            end
        end
    end

    methods (Static)
        function nmb = GetLength()
            nmb = length(enumeration('ElementType'));
        end

        function outnames = GetNames()
            [~,outnames] = enumeration('ElementType');
        end    
    end
    
end