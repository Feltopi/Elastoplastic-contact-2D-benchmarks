classdef ElementLineSegment < Element
    %ELEMENTQUAD Summary of this class goes here
    %   Detailed explanation goes here
    
    methods
        function [Xi,WF] = QuadratureVolume(obj)
            error("Not implemented yet")
        end
        
        function [HatP,DHatP1,DHatP2] = LocalBasisVolume(obj,Xi)
            error("Not implemented yet")
        end
    end
end

