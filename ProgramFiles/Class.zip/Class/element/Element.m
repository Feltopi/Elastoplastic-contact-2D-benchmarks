classdef (Abstract) Element < handle
    %ELEMENT Summary of this class goes here
    %   Detailed explanation goes here
    properties
        nodes   % idx of nodes which defines the element
    end
    
    methods
        % return number of stored elements
        function nmb = GetNelements(obj)
            nmb = size(obj.nodes,2);
        end
        
        % return number of integration points
        function n_q = GetNintpoints(obj)
            [~,WF] = obj.QuadratureVolume();
            n_q = length(WF);
        end        
    end

    methods (Abstract)
        QuadratureVolume(obj)
        LocalBasisVolume(obj,Xi)
    end
end

