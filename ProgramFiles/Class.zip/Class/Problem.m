classdef Problem < handle
    properties
        name                     % name of problem
        bodies                   % cell array of struct Body
        bodyGroups               % cell array of body groups
        bcDirichlets             % cell array of Dirichlet boundary conditions
        bcNeumanns               % cell array of Neumann boundary conditions
        bcMortars                % cell array of Mortar boundary conditions
        bcContactRigids          % cell array of ContactRigid boundary conditions

        dim
        thickness
    end

    methods
        function obj = Problem(dim,name)
            arguments
                dim
                name = '';
            end
            % constructor
            obj.name = name;
            obj.bodies = [];
            obj.bcDirichlets = [];
            obj.bcNeumanns = [];
            obj.bcMortars = [];
            obj.bcContactRigids = [];

            obj.dim = dim;
            obj.thickness = 1;
        end

        function Info(obj)
            % print info about this object
            % TODO
        end

        %% Plot
        function Plot(obj)
            plotProblem(obj);
        end

        function PlotDeformed(obj,assembler)
            PlotDeformedProblem(obj,assembler);
        end

        function PlotDeformedBody(obj,assembler,id_body,multiplier)
            % TODO
            nDomains = length(assembler.domains);

            for domainID=1:nDomains
                rBody = reshape(assembler.rvec.blocks{domainID},obj.dim,assembler.domains{domainID}.GetNNodes())'*multiplier;
                plotDeformedBody(assembler.domains{domainID},rBody);
            end
        end

        function PlotDeformedBodies(obj,assembler,id_bodies,multiplier)
            for i = 1:length(id_bodies)
                PlotDeformedBody(obj,assembler,id_bodies(i),multiplier)
            end

        end

        %% Append body
        function obj = AppendBody(obj,newBody)
                % Append new body
                obj.bodies{end+1} = newBody;
        end

%         function [] = AppendFETIBody(obj,fetiBody)
%             nDomains = length(fetiBody.domains);
%             localBody2Global = zeros(nDomains,1);
% 
%             for i=1:length(fetiBody.domains)
%                 obj.bodies{end+1} = fetiBody.domains{i};
%                 localBody2Global(i) = length(obj.bodies);
%             end
% 
%             obj.bodyGroups{end+1} = BodyGroup(fetiBody.name,localBody2Global,fetiBody.surfaces);
% 
%             for i=1:length(fetiBody.glueConstraints)
%                 id_body1 = localBody2Global(fetiBody.glueConstraints{i}.id_body1);
%                 id_body2 = localBody2Global(fetiBody.glueConstraints{i}.id_body2);
%                 obj.appendBc(BcMortar(id_body1,fetiBody.glueConstraints{i}.id_surface1, ...
%                     id_body2, fetiBody.glueConstraints{i}.id_surface2, MortarType.glue_s2s));
%             end
%         end

        %% Append boundary condition
        function [] = AppendBc(obj,newCond)
            % Append new condition to corresponding type

            if isa(newCond,'BcDirichlet')
                obj.AppendDirichletBc(newCond);
            end

            if isa(newCond,'BcNeumann')
                obj.AppendNeumannBc(newCond);
            end

            if isa(newCond,'BcContactRigid')
                obj.AppendContactRigidBc(newCond);
            end

            if isa(newCond,'BcMortar')
                obj.AppendMortarBc(newCond);
            end
        end

        function [] = AppendDirichletBc(obj,dirichletBc)
            % Name to body id
            if(isa(dirichletBc.id_body,"string"))
                dirichletBc.id_body = obj.FindBody(dirichletBc.id_body);
            end

            if(dirichletBc.id_body > 0) % Append body
                obj.bcDirichlets{end+1} = dirichletBc;
            elseif(dirichletBc.id_body < 0) % Append body group
                AppendGroupDirichletBc(dirichletBc);
            else
                error("Invalid body id")
            end
        end

        function [] = AppendGroupDirichletBc(obj,dirichletBc)
            localBody2Global = obj.bodyGroups{abs(dirichletBc.id_body)}.localBody2Global;
            localSurface2Surface = obj.bodyGroups{abs(dirichletBc.id_body)}.localSurface2Surface{dirichletBc.id_surface};
            globalBodyID = localBody2Global(localSurface2Surface(:,1));

            for i=1:length(globalBodyID)
                obj.AppendBc(BcDirichlet(globalBodyID(i),localSurface2Surface(i,2),dirichletBc.values));
            end
        end

        function [] = AppendNeumannBc(obj,neumannBc)
            % Name to body id
            if(isa(neumannBc.id_body,"string"))
                neumannBc.id_body = obj.FindBody(neumannBc.id_body);
            end

            obj.bcNeumanns{end+1} = neumannBc;
        end

        function [] = AppendGroupNeumannBc(obj,neumannBc)
            localBody2Global = obj.bodyGroups{abs(neumannBc.id_body)}.localBody2Global;
            localSurface2Surface = obj.bodyGroups{abs(neumannBc.id_body)}.localSurface2Surface{neumannBc.id_surface};
            globalBodyID = localBody2Global(localSurface2Surface(:,1));

            for i=1:length(globalBodyID)
                obj.AppendBc(BcNeumann(globalBodyID(i),localSurface2Surface(i,2),neumannBc.values));
            end
        end

        function [] = AppendContactRigidBc(obj,contactRigidBc)
            % Name to body id
            if(isa(contactRigidBc.id_body,"string"))
                contactRigidBc.id_body = obj.FindBody(contactRigidBc.id_body);
            end

            if(contactRigidBc.id_body > 0) % Append body
                obj.bcContactRigids{end+1} = contactRigidBc;
            elseif(contactRigidBc.id_body < 0) % Append body group
                obj.AppendGroupContactRigidBc(contactRigidBc);
            else
                error("Invalid body id")
            end
        end

        function [] = AppendGroupContactRigidBc(obj,contactRigidBc)
            localBody2Global = obj.bodyGroups{abs(contactRigidBc.id_body)}.localBody2Global;
            localSurface2Surface = obj.bodyGroups{abs(contactRigidBc.id_body)}.localSurface2Surface{contactRigidBc.id_surface};
            globalBodyID = localBody2Global(localSurface2Surface(:,1));

            for i=1:length(globalBodyID)
                obj.AppendBc(BcContactRigid(globalBodyID(i),localSurface2Surface(i,2),contactRigidBc.values_lower,contactRigidBc.values_upper));
            end
        end

        function [] = AppendMortarBc(obj,mortarBc)
            % Name to body id
            if(isa(mortarBc.id_body1,"string"))
                mortarBc.id_body1 = obj.FindBody(mortarBc.id_body1);
            end

            % Name to body id
            if(isa(mortarBc.id_body2,"string"))
                mortarBc.id_body2 = obj.FindBody(mortarBc.id_body2);
            end

            if(mortarBc.id_body1 > 0 && mortarBc.id_body2 > 0) %% Append to body
                obj.bcMortars{end+1} = mortarBc;
            else
                error("TODO")
            end
        end

        function obj = AppendBcDirichlet_zero(obj,id_body,id_surface)
            % shortcut - set zero Dirichlet on whole surface

            if(isa(id_body,"string"))
                id_body = obj.FindBody(id_body);
            end

            obj.AppendBc(BcDirichlet(id_body,id_surface,[0,0]));

%             if(id_body > 0) %% Append to body
%                 obj.appendBc(BcDirichlet(id_body,id_surface,...
%                     zeros(size(obj.bodies{id_body}.surfaces{id_surface}.nodes,1),obj.dim)));
% 
%             elseif(id_body < 0) %% Append to body group
%                 localBody2Global = obj.bodyGroups{abs(id_body)}.localBody2Global;
%                 localSurface2Surface = obj.bodyGroups{abs(id_body)}.localSurface2Surface{id_surface};
%                 globalBodyID = localBody2Global(localSurface2Surface(:,1));
% 
%                 for i=1:length(globalBodyID)
%                     obj.appendBcDirichlet_zero(globalBodyID(i),localSurface2Surface(i,2));
%                 end
%             else
%                 error("Invalid id_body")
%             end
        end

        function obj = AppendBcContactRigid_empty(obj,id_body,id_surface)
            % shortcut - append unconstrained Rigid contact with appropriate size

            if(isa(id_body,"string"))
                id_body = obj.FindBody(id_body);
            end

            if(id_body > 0) %% Append to body
                obj.AppendBc(BcContactRigid(id_body,id_surface,...
                    -Inf*ones(size(obj.bodies{id_body}.surfaces{id_surface}.nodes,1),obj.dim),...
                    Inf*ones(size(obj.bodies{id_body}.surfaces{id_surface}.nodes,1),obj.dim)));

            elseif(id_body < 0) %% Append to body group
                localBody2Global = obj.bodyGroups{abs(id_body)}.localBody2Global;
                localSurface2Surface = obj.bodyGroups{abs(id_body)}.localSurface2Surface{id_surface};
                globalBodyID = localBody2Global(localSurface2Surface(:,1));

                for i=1:length(globalBodyID)
                    obj.AppendBcDirichlet_zero(globalBodyID(i),localSurface2Surface(i,2));
                end
            else
                error("Invalid id_body")
            end
        end

        function obj = AppendBcNeumann_to_node_constant(obj,id_body,id_surface,value)
            % shortcut - set zero Dirichlet on whole surface
            obj.AppendBc(BcNeumann(id_body,id_surface,...
                value.*ones(size(obj.bodies{id_body}.surfaces{id_surface}.nodes,1),1)));
        end

        %% Get counts
        function n = GetNBodies(obj)
            n = length(obj.bodies);
        end

        function n = GetNDomains(obj)
            n = 0;
            for i = 1:length(obj.bodies)
                n = n + obj.bodies{i}.GetNDomains();
            end
        end

       function nmb = GetNElements(obj)
            nmb = zeros(length(obj.bodies),1);
            for i = 1:length(obj.bodies)
            	nmb(i) = sum(obj.bodies{i}.GetNElements());
            end
        end         
        
        function n = GetNBcNeumanns(obj)
            n = length(obj.bcNeumanns);
        end

        function n = GetNBcDirichlets(obj)
            n = length(obj.bcDirichlets);
        end

        function n = GetNBcMortars(obj)
            n = length(obj.bcMortars);
        end

        function n = GetNBcContactRigids(obj)
            n = length(obj.bcContactRigids);
        end

        function [n,ns] = GetNdofsBcDirichlets(obj)
            % compute how many nodes are affected by Dirichlet conditions
            % i.e., get number of rows in equality matrix
            ns = zeros(obj.GetNBcDirichlets(),1);
            for i=1:obj.GetNBcDirichlets()
                ns(i) = obj.bcDirichlets{i}.getNdofs();
            end
            n = sum(ns);
        end

        %% Utility
        function [bodyID] = FindBody(obj,name)
            % find surface idx based on the name
            for i=1:length(obj.bodies)
                if strcmp(name,obj.bodies{i}.name)
                    bodyID = i;
                    return
                end
            end

            for i=1:length(obj.bodyGroups)
                if strcmp(name,obj.bodyGroups{i}.name)
                    bodyID = -i;
                    return
                end
            end
        end

        function obj = Save(obj,filename)
            % save problem from .mat file

            save(filename,'obj');
        end

    end

    methods(Static)
        function [myproblem,sigma] = ReadAnsysFile(fileDirection,loadSigma)
            % import problem from Ansys file
            arguments
                fileDirection
                loadSigma = false;
            end

            [myproblem,sigma] = ReadAnsysFile(fileDirection,loadSigma);
        end

        function myproblem = Load(filename)
            % load problem from .mat file

            a = load(filename);
            myproblem = a.obj;
        end        
    end
    
end

