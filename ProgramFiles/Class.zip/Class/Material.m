classdef Material < handle
    properties
        elasticity
        plasticity

        isPlastic;
    end

    methods
        function obj = Material(elasticProperties, plasticProperties)
            arguments
                elasticProperties = IsotropicElasticity();
                plasticProperties = [];
            end
            % constructor
            obj.elasticity = elasticProperties;
            obj.plasticity = plasticProperties;
            obj.isPlastic = false;

            obj.SetPlastic();
        end

        function Info(obj)
            % print info about this object
            % TODO
        end

        function SetPlastic(obj)
            if(~isempty(obj.plasticity))
                obj.isPlastic = true;
            end
        end

        function isPlastic = IsPlastic(obj)
            isPlastic = obj.isPlastic;
        end
    end
end

