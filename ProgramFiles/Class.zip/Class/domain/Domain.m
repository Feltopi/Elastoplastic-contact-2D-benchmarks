classdef Domain < handle
    % Domain the object which keeps information of the domain
    %    The domain is defined by coordinates of nodes, elements of different
    %    types and surfaces. The material and thickness of the body have to be given.
    %
    %% See also: 
    %   BODY, MATERIAL, MATERIALTYPE

    properties
        name                 % name of Domain
        idDomain             % id Domain in this Body

        nameBody             % name of parent Body

        dim                  % dimension of Domain

        material             % Domain material
        thickness            % 2D Domain thickness

        coordinates          % matrix of nodes, each row is coordinates [x,y] or [x,y,z]
        elements             % cell array with elements
        
        surfaces             % cell array cell aray of surface of individual sides
    end

    methods
        function obj = Domain(dim,nameBody,idDomain)
            % Constructor: initialize empty body
            arguments
                dim = 0;
                nameBody = 'parentBody';
                idDomain = 0;
            end

            obj.dim = dim;
            obj.nameBody = nameBody;
            obj.idDomain = idDomain;
            obj.name = append(nameBody,"_D",num2str(idDomain));

            % empty elements
            obj.elements = cell(ElementType.GetLength(),1);
            typenames = ElementType.GetNames();
            for i = 1:length(obj.elements)
                % call constructor of every element type
                eval(strcat("obj.elements{",num2str(i),"} = Element",typenames{i},"();"));
            end

        end

        function Info(obj)
            % print info about this object
            % TODO
        end

        function Plot(obj)
            % plot domain
            % TODO
        end

        function n = GetNNodes(obj)
            % return number of nodes based on size of coordinates matrix

            n = size(obj.coordinates,1);
        end

        function obj = AppendSurface(obj,newSurface)
            % append new surface to the domain
            obj.surfaces{end+1} = newSurface;
        end        
    end
end

