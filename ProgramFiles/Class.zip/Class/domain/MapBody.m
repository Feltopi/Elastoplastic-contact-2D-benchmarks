classdef MapBody < handle
    properties (Access = private)
        domainIdx
        surfaceIdx
    end

    methods
        function obj = MapBody(nDomains)
            % constructor
            arguments
                nDomains = 1;
            end

            obj.domainIdx = (1:nDomains)';
            obj.surfaceIdx = cell(nDomains,1);
            for idSurface = 1:nDomains
                obj.surfaceIdx{idSurface} = [];
            end
        end

        function domainIdx = GetDomainIdx(obj)
            domainIdx = obj.domainIdx;
        end

        function obj = ShiftDomainIdx(obj,shift)
            obj.domainIdx = obj.domainIdx + shift;
        end

        function obj = AddSurfaceMap(obj,idDomain,bodySurfaceID)
            obj.surfaceIdx{idDomain} = [obj.surfaceIdx{idDomain};bodySurfaceID];
        end

        function obj = SetSurfaceMap(obj,idDomain,bodySurfaceIDs)
            obj.surfaceIdx{idDomain} = bodySurfaceIDs;
        end

        function Info(obj)
            % print info about this object
            nDomains = length(obj.domainIdx);

            disp('---- MapBody -----');
            disp(['Domains: ' num2str(nDomains)]);
            for idDomain = 1:nDomains
                disp([num2str(idDomain) '. domain']);
                disp([' idBody:   ' num2str(obj.domainIdx(idDomain))]);
                disp([' Surfaces: ' vec2str(obj.surfaceIdx{idDomain})]);
            end

        end

        function [idDomains,idSurfaces] = FindGlobalDomains(obj,idSurface)
            % return vector of domains (GlobalIdx) which have given surface
            
            idDomains = [];
            idSurfaces = [];
            nDomains = length(obj.domainIdx);
            for idDomain = 1:nDomains
                % find surface in this domain
                idSurfaceInDomain = find(obj.surfaceIdx{idDomain} == idSurface);
                
                if ~isempty(idSurfaceInDomain)
                    idDomains = [idDomains;obj.domainIdx(idDomain)];
                    idSurfaces = [idSurfaces;idSurfaceInDomain];
                end
            end
        end
    end
end

