classdef SolverOptions < handle
    properties
        solverType      % type of used solver
        
        steps           % number of steps in pseudotime
        
        NewtonMaxIt     % maximum number of iterations in Newton method 
        NewtonEps       % stopping criteria for Newton method
        
        quadprogOptions % options for used quadprog
        smalseOptions   % options for used smalse algorithm

        use_projector
        use_orthogonalization    
    end
    
    methods
        function obj = SolverOptions()
            % constructor
            obj.solverType = SolverType.auto;
            obj.steps = 10;
            
            obj.NewtonMaxIt = 1000;
            obj.NewtonEps = 1e-5;
            
            % default quadprog options
            obj.quadprogOptions = optimoptions('quadprog');
            obj.quadprogOptions.Display = 'none';
            obj.quadprogOptions.MaxIterations = 1e3;
            obj.quadprogOptions.OptimalityTolerance = 1e-12;
            obj.quadprogOptions.ConstraintTolerance = 1e-12;
            obj.quadprogOptions.StepTolerance = 1e-16;

            % default smalse options
            obj.smalseOptions = SmalseOptions();

            obj.use_projector = true;
            obj.use_orthogonalization = true;
       
        end
        
        function Info(obj)
            % print info about this object
            % TODO
        end
    end
end

