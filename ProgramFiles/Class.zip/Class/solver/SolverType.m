classdef SolverType
    enumeration
        auto                                       % choose automatic solver

        elasticity_Matlab_primal                   % solve QP in primal formulation
        elasticity_Matlab_dual                     % solve QP using dual formulation
        plasticity_Matlab_dual                     % solve QP using dual formulation, compute Mortar

        elasticity_Smalbe_dual                     % solve QP using dual formulation
        plasticity_Smalbe_dual                     % solve QP using dual formulation, compute Mortar
        
        unsolvable                                 % I don't know how to solve this type of problem
    end
end