classdef Solver < handle
    % Solver a class for solving the problem
    %   This class solves the assembled problem with given options

    properties
        assembler Assembler
        perf

        options
        solved
    end

    methods
        function obj = Solver(assembler,options)
            arguments
                assembler = [];
                options = SolverOptions();
            end

            % constructor
            obj.assembler = assembler;
            obj.perf = PerfSolver();
            obj.options = options;
            obj.solved = false; % the problem is not solved
        end

        function Info(obj)

            % print info about this object
            % TODO
        end

        function obj = ChooseAutoSolver(obj)
            % select the most appropriate solver to solve this problem
            obj.options.solverType = SolverChooseType(obj.assembler);
        end

        function obj = ChooseAutoSolverMatlab(obj)
            % select the most appropriate solver to solve this problem
            % use Matlab solver
            obj.options.solverType = SolverChooseTypeMatlab(obj.assembler);
        end

        function obj = Solve(obj)
            % the type is chosen to be auto, therefore decide what to do
            if obj.options.solverType == SolverType.auto
                obj.ChooseAutoSolver();
            end

            if obj.options.solverType == SolverType.unsolvable
                % we don't know how to solve this problem
                error("Solver: I don't know how to solve given problem.")
            else
                % call the function based on the enum value
                % compose the function name as "solve_"+SolverType and add arguments [problem,assembler]
                functionName = sprintf('solve_%s',obj.options.solverType);
                [obj.solved,obj.perf] = feval(functionName, obj.assembler, obj.options);
            end

            if obj.solved
                obj.assembler.ComputeStress();
            end
        end

        function myfig = PlotStress(obj,plotStressType,show)
            if nargin == 2
                show = true;
            end
            myfig = DrawStress(obj.assembler,plotStressType,show);
        end

        function myfig = PlotBodyStress(obj,id_body,plotStressType)
            myfig = DrawBodyStress(obj.assembler,id_body,plotStressType);
        end

        function myfig = PlotImportedStress(obj,importedSigma,plotStressType,show)
            myfig = DrawImportedStress(obj.assembler,importedSigma,plotStressType,show);
        end

        function myfig = PlotStressDifference(obj,importedSigma,plotStressType,show)
            myfig = DrawStressDifference(obj.assembler,importedSigma,plotStressType,show);
        end

        function myfig = PlotStressRelativeDifference(obj,importedSigma,plotStressType)
            myfig = DrawStressRelativeDifference(obj.assembler,importedSigma,plotStressType);
        end

        function myfig = PlotStrain(obj,plotStrainType)
            myfig = DrawStrain(obj.assembler,plotStrainType);
        end

        function PlotDeformed(obj)
            DrawDeformed(obj.assembler);
        end

        function PlotContactPressure(obj)
            DrawContactPressure(obj.assembler);
        end
    end
end

