classdef IsotropicElasticityPlaneStrain < IsotropicElasticity
    methods
        function [] = BulkAndShearModulus(obj)
            obj.bulk = obj.E/(3*(1-2*obj.v));
            obj.shear = obj.E/(2*(1+obj.v));
        end
    end
end

