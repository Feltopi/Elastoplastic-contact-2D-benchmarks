classdef IsotropicElasticity < handle
    properties
        E                    % Youngs modulus
        v                    % Poissons ratio
        bulk                 % Bulk modulus
        shear                % Shear modulus
    end

    methods
        function obj = IsotropicElasticity(E,v)
            arguments
                E = 210*10^9;
                v = 0.3;
            end
            % constructor
            obj.E = E;
            obj.v = v;
            obj.BulkAndShearModulus;
        end

        function Info(obj)
            % print info about this object
            % TODO
        end
    end

    methods
        function [] = BulkAndShearModulus(obj)
            obj.bulk = obj.E/(3*(1-2*obj.v));
            obj.shear = obj.E/(2*(1+obj.v));
        end
    end
end

