classdef BilinearKinematicHardening < handle
    properties
        Y                    % yield strength
        a                    % hardening modulus
    end

    methods
        function obj = BilinearKinematicHardening(fy,a)
            arguments
                fy = 235*10^6;
                a = 0;
            end
            % constructor
            obj.Y = fy;
            obj.a = a;
        end

        function Info(obj)
            % print info about this object
            % TODO
        end
    end
end

