classdef (Abstract) Body < handle
    % Body the object which keeps information of the body
    %    The body is defined by coordinates of nodes, elements of different
    %    types and surfaces. The material and thickness of the body have to be given.
    %
    %% See also: 
    %   MATERIAL, MATERIALTYPE

    properties
        name                 % name of body
        dim                  % dimension of body

        material             % body material
        thickness            % 2D body thickness

        surfaces             % cell array of matrices of surfaces, each row consists of nodes of boundary surface

        nDomains             % number of domains
    end

    methods(Access = 'protected')
        function obj = Body(dim,name)
            % Constructor: initialize empty body
            arguments
                dim
                name = 'Body';
            end

            obj.name = name;
            obj.dim = dim;
            obj.material = Material();
            obj.thickness = 1;

            obj.surfaces = [];
            obj.nDomains = 1;

        end
    end
    
    methods
        function n = GetNDomains(obj)
            n = obj.nDomains;
        end

        function obj = SetNDomains(obj,nDomains)
            obj.nDomains = nDomains;
        end

        function n = GetNSurfaces(obj)
            n = length(obj.surfaces);
        end

        function obj = AppendSurface(obj,newSurface)
            % append new surface to the body
            
            if ~isa(newSurface,'Surface')
                error('Body: cannot append surface')
            else
                % append new surface
                obj.surfaces{end+1} = newSurface;
            end
        end

        function idx = FindSurface(obj,name)
            % find surface index based on the name

            idx = [];
            for i=1:length(obj.surfaces)
                if strcmp(name,obj.surfaces{i}.name)
                    idx = i;
                end
            end

            if isempty(idx)
                error(strcat("Body: surface with name '", name, "' not found"))
            end
        end

        function SetMaterial(obj,material)
            obj.material = material;
        end

        function SetThickness(obj,thickness)
            obj.thickness = thickness;
        end        

    end

    methods (Abstract)
        Info()
        Plot()
        ToDomains()
    end
end

