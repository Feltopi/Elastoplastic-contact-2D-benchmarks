classdef BodyMesh < Body
    % BodyMesh the object which keeps information of the body
    %    The body is defined by coordinates of nodes, elements of different
    %    types and surfaces. The material and thickness of the body have to be given.
    %
    %% See also:
    %   MATERIAL, MATERIALTYPE

    properties
        coordinates          % matrix of nodes, each row is coordinates [x,y] or [x,y,z]
        elements             % cell array with elements
    end

    methods
        function obj = BodyMesh(dim,name,coordinates)
            % Constructor: initialize empty body
            arguments
                dim
                name
                coordinates = [];
            end

            obj@Body(dim,name); % call constructor
            obj.coordinates = coordinates;

            % empty elements
            obj.elements = cell(ElementType.GetLength(),1);
            typenames = ElementType.GetNames();
            for i = 1:length(obj.elements)
                % call constructor of every element type
                eval(strcat("obj.elements{",num2str(i),"} = Element",typenames{i},"();"));
            end

        end

        function Info(obj)
            % print info about this object
            % TODO
        end

        function Plot(obj)
            % plot body

            plotBody(obj);
        end

        function obj = SetElementNodes(obj,elementType,new_nodes)
            % set elements of given type

            obj.elements{int(elementType)}.nodes = new_nodes;
        end

        function obj = AppendElementNodes(obj,elementType,new_nodes)
            % append elements of given type to the body

            obj.elements{int(elementType)}.nodes = [obj.elements{int(elementType)}.nodes;new_nodes];
        end

        function nodes_out = GetElementNodes(obj,elementType)
            % returns nodes of given type of element

            nodes_out = obj.elements{int(elementType)}.nodes;
        end

        function elements_out = GetElements(obj,elementType)
            % returns elements of given type

            elements_out = obj.elements{int(elementType)};
        end

        function nmb = GetNElements(obj)
            % get total number of elements of the body

            nmb = zeros(ElementType.GetLength(),1);
            for i = 1:ElementType.GetLength()
                nmb(i) = obj.elements{i}.GetNelements();
            end
        end

        function n = GetNnodes(obj)
            % return number of nodes based on size of coordinates matrix

            n = size(obj.coordinates,1);
        end

        function [domains,mapBody,glueConstraints] = ToDomains(obj)

            if obj.nDomains <= 1
                % direct transfer BodyMesh to Domain
                dim = obj.dim;
                nameBody = obj.name;
                idDomain = 1;
                domains = {Domain(dim,nameBody,idDomain)};

                domains{1}.coordinates = obj.coordinates;
                domains{1}.elements = obj.elements;
                domains{1}.material = obj.material;
                domains{1}.thickness = obj.thickness;
                domains{1}.surfaces = obj.surfaces;

                % prepare mapping of bodies to domains
                mapBody = MapBody(obj.nDomains); % should be [1]

                idDomain = 1;
                bodySurfaceIDs = (1:length(obj.surfaces))';
                mapBody.SetSurfaceMap(idDomain,bodySurfaceIDs);

                % no gluing
                glueConstraints = [];
            else
                % decompose mesh
                [domains,mapBody,bodyGlueConstraints] = DomainDecomposition(obj);

                % process gluing constraints to the form of Mortar
                % constraints
                nGlueConstraints = length(bodyGlueConstraints);
                glueConstraints = zeros(nGlueConstraints,5);

                domainIdx = mapBody.GetDomainIdx();
                for idConstraint=1:nGlueConstraints
                    glueConstraints(idConstraint,1) = domainIdx(bodyGlueConstraints{idConstraint}.id_body1);
                    glueConstraints(idConstraint,2) = bodyGlueConstraints{idConstraint}.id_surface1;
                    glueConstraints(idConstraint,3) = domainIdx(bodyGlueConstraints{idConstraint}.id_body2);
                    glueConstraints(idConstraint,4) = bodyGlueConstraints{idConstraint}.id_surface2;
                    glueConstraints(idConstraint,5) = bodyGlueConstraints{idConstraint}.mortarType.int;
                end

            end
        end
    end
end

